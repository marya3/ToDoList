/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import view.TaskDTO;

/**
 *
 * @author tmp-sda-1161
 */
public class TaskRepositoryTest {
    
    public TaskRepositoryTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addTask method, of class TaskRepository.
     */
    @Test
    public void testAddTask() {
        System.out.println("addTask");
        TaskDTO tdto = null;
        TaskRepository instance = new TaskRepository();
        instance.addTask(tdto);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNextTask method, of class TaskRepository.
     */
    @Test
    public void testGetNextTask() {
        System.out.println("getNextTask");
        TaskRepository instance = new TaskRepository();
        TaskDTO expResult = null;
        TaskDTO result = instance.getNextTask();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPrevTask method, of class TaskRepository.
     */
    @Test
    public void testGetPrevTask() {
        System.out.println("getPrevTask");
        TaskRepository instance = new TaskRepository();
        TaskDTO expResult = null;
        TaskDTO result = instance.getPrevTask();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of readFromFile method, of class TaskRepository.
     */
    @Test
    public void testReadFromFile() {
        System.out.println("readFromFile");
        TaskRepository instance = new TaskRepository();
        instance.readFromFile();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of writeToFile method, of class TaskRepository.
     */
    @Test
    public void testWriteToFile() {
        System.out.println("writeToFile");
        TaskRepository instance = new TaskRepository();
        instance.writeToFile();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of editTask method, of class TaskRepository.
     */
    @Test
    public void testEditTask() {
        System.out.println("editTask");
        int Tno = 0;
        int attrib = 0;
        String value = "";
        TaskRepository instance = new TaskRepository();
        instance.editTask(Tno, attrib, value);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of initializeIT method, of class TaskRepository.
     */
    @Test
    public void testInitializeIT() {
        System.out.println("initializeIT");
        TaskRepository instance = new TaskRepository();
        instance.initializeIT();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
