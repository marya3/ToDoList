/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.ProcessCommand;
import java.io.ByteArrayInputStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import java.io.InputStream;

import static org.junit.Assert.*;

/**
 *
 * @author tmp-sda-1161
 */
public class CmdLineInterfaceTest {
    
    CmdLineInterface instance; 

    public CmdLineInterfaceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
       instance = new CmdLineInterface(new ProcessCommand());
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of startApplication method, of class CmdLineInterface.
     */
    /*@Test
    public void testStartApplication() {
        System.out.println("startApplication");
        CmdLineInterface instance = null;
        instance.startApplication();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showMainMenu method, of class CmdLineInterface.
     */
   /* @Test
    public void testShowMainMenu() {
        System.out.println("showMainMenu");
        CmdLineInterface instance = null;
        instance.showMainMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of getUserInput method, of class CmdLineInterface.
     */
    @Test
    public void testGetUserInput() {
        System.out.println("getUserInput");
        int expResult = 1;

        String input = "1";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        //assertEquals("add 5", inputOutput.getInput());
        //int result = instance.getUserInput();
        //System.out.println("HERE IS THE NOUR RESULT: " + result);
        assertEquals(expResult, instance.getUserInput());
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of addTask method, of class CmdLineInterface.
     */
   /* @Test
    public void testAddTask() {
        System.out.println("addTask");
        CmdLineInterface instance = null;
        instance.addTask();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of editTask method, of class CmdLineInterface.
     */
    /*@Test
    public void testEditTask() {
        System.out.println("editTask");
        CmdLineInterface instance = null;
        instance.editTask();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showReportHeading method, of class CmdLineInterface.
     */
   /* @Test
    public void testShowReportHeading() {
        System.out.println("showReportHeading");
        CmdLineInterface instance = null;
        instance.showReportHeading();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showReport method, of class CmdLineInterface.
     */
   /* @Test
    public void testShowReport() {
        System.out.println("showReport");
        CmdLineInterface instance = null;
        instance.showReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/
    
}
