/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tmp-sda-1161
 */
package model;

import java.util.ArrayList;
import java.util.ListIterator;
import view.TaskDTO;
import dbhandler.FileHandler;

public class TaskRepository {
    FileHandler fh;    
    ArrayList<Task> taskList;
    ListIterator<Task> taskIT;

    public TaskRepository()
    {
        fh = new FileHandler();
        taskList = new ArrayList<>();
    
    }
    
    public void addTask(TaskDTO tdto)
    {
        Task task = new Task(tdto);
        taskList.add(task);
        
    }
    
    public TaskDTO getNextTask()
    {
        Task tk;
        if (taskIT.hasNext())
        {
            tk = (Task) taskIT.next();
            TaskDTO tdto = new TaskDTO
                    (tk.getProject(),
                     tk.getTitle(),
                     tk.getDueDate(),
                     tk.getCompletionDate(),
                     tk.getStatus(),
                     tk.getAlert()
                    );
            return tdto;
        }
        return null;
    }
    
    public TaskDTO getPrevTask()
    {
        
        Task tk;
        if (taskIT.hasPrevious())
        {
            tk = (Task) taskIT.previous();
            TaskDTO tdto = new TaskDTO
                    (tk.getProject(),
                     tk.getTitle(),
                     tk.getDueDate(),
                     tk.getCompletionDate(),
                     tk.getStatus(),
                     tk.getAlert()
                    );
            return tdto;
        }
        return null;
        
    }
    
    public void readFromFile()
    {
        
        Object o;
        o = fh.readFile();
        while (o!= null)
        {
            taskList.add((Task)o);
            o = fh.readFile();
        }
        
    }
    
    public void writeToFile()
    {
        fh.writeFile(taskList);
    }
    
    
    public void editTask(int Tno, int attrib, String value)
    {
        Task tk = taskList.get(Tno);
        if (tk != null)
        {
            switch(attrib)
            {
                case 1: tk.setProject(value);break;
                case 2: tk.setTitle(value);break;
                case 3: tk.setDueDate(value);
                case 4: tk.setStatus(value);break;
                case 5: taskList.remove(tk);
            }
        }
    }
    
    public void initializeIT()
    {
        taskIT = taskList.listIterator();
    }
}
